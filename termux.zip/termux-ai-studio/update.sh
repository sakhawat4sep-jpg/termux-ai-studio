#!/usr/bin/env bash
# Updates this repo, llama.cpp and OpenCode. Never touches your model or user config.
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/scripts/lib.sh"
if [ -d "$TAS_ROOT/.git" ]; then info "git pull"; git -C "$TAS_ROOT" pull --ff-only || warn "git pull failed (local changes?)"; fi
if have pkg; then pkg upgrade -y llama-cpp jq nodejs || warn "pkg upgrade failed"; fi
if have npm; then npm install -g opencode-ai || warn "OpenCode update failed"; fi
bash "$TAS_ROOT/scripts/configure-opencode.sh"
ok "Update done. Restart server: ai stop && ai start"
