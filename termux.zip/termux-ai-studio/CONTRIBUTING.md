# Contributing

1. Fork, branch, make focused changes.
2. Before a PR run: `for f in *.sh scripts/*.sh bin/ai; do bash -n "$f"; done`, `shellcheck` if available, and `jq empty config/opencode.json`.
3. Keep scripts non-destructive: back up before modifying user files, no hardcoded paths, no secrets.
4. Mark anything you could not test on a real device as untested in docs/VERIFICATION.md.
5. Never commit model weights.
