#!/usr/bin/env bash
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/scripts/lib.sh"
if ! pid_alive; then info "Server is not running."; rm -f "$PID_FILE"; have termux-wake-unlock && termux-wake-unlock || true; exit 0; fi
pid="$(cat "$PID_FILE")"
kill "$pid" 2>/dev/null || true
for _ in $(seq 1 15); do kill -0 "$pid" 2>/dev/null || break; sleep 1; done
if kill -0 "$pid" 2>/dev/null; then warn "Still running; sending SIGKILL."; kill -9 "$pid" 2>/dev/null || true; fi
rm -f "$PID_FILE"
have termux-wake-unlock && termux-wake-unlock || true
ok "Server stopped."
