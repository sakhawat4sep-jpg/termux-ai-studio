# Security

- The server binds to 127.0.0.1 only; the scripts refuse other hosts unless `ALLOW_NON_LOCAL=1`.
- llama-server has no authentication by default. Never expose it publicly or tunnel it without an API key and TLS.
- No API keys or secrets are stored or required.
- Config files are backed up (`*.bak.<timestamp>`) before modification.
- Model files are downloaded over HTTPS from Hugging Face and checked (GGUF header, size, SHA-256 when available). Only download models from sources you trust.
- OpenCode can run shell commands and edit files. Review its actions; keep it away from sensitive directories.

Report vulnerabilities privately via GitHub Security Advisories on this repository.
