#!/usr/bin/env bash
# Diagnostics. Exit code = number of failed checks.
set -uo pipefail
. "$(dirname "$(readlink -f "$0")")/scripts/lib.sh"
load_config
bad=0
chk() { if eval "$2" >/dev/null 2>&1; then ok "$1"; else err "$1  -> $3"; bad=$((bad+1)); fi; }
echo "== Termux AI Studio doctor ($TAS_VERSION) =="
chk "Termux / ARM64"        '[ "$(uname -m)" = aarch64 ] || [ "$(uname -m)" = arm64 ]' "ARM64 required (uname -m)"
chk "curl installed"        'have curl' "pkg install curl"
chk "jq installed"          'have jq' "pkg install jq"
chk "llama-server found"    'have llama-server' "pkg install llama-cpp"
chk "Model configured"      '[ -n "$MODEL_FILE" ]' "ai model set OWNER/REPO FILE.gguf"
chk "Model file valid"      'bash "$TAS_ROOT/scripts/verify-model.sh"' "ai model download"
chk "Free storage >= 1 GB"  '[ "$(free_mb "$HOME")" -ge 1024 ]' "free up space"
chk "Server host is local"  'case "$SERVER_HOST" in 127.0.0.1|localhost|::1) true;; *) false;; esac' "SERVER_HOST must be 127.0.0.1"
chk "Server running"        'pid_alive' "ai start"
chk "Server healthy"        'api_health' "ai logs"
chk "OpenCode installed"    'have opencode' "see TROUBLESHOOTING: npm installation failures"
chk "OpenCode config valid JSON" 'jq empty "$OPENCODE_CONF"' "bash scripts/configure-opencode.sh"
chk "OpenCode provider points to local server" 'jq -e --arg p "$PROVIDER_ID" --arg u "http://$SERVER_HOST:$SERVER_PORT/v1" ".provider[\$p].options.baseURL==\$u" "$OPENCODE_CONF"' "bash scripts/configure-opencode.sh"
chk "OpenCode default model is local" 'jq -e --arg m "$PROVIDER_ID/$MODEL_ALIAS" ".model==\$m" "$OPENCODE_CONF"' "bash scripts/configure-opencode.sh"
[ "$CTX" -lt 4096 ] && warn "CTX=$CTX is small; OpenCode may report context overflow. Try: ai model ctx 4096 (or 8192 if RAM allows)."
[ "$(mem_avail_mb)" -lt 1800 ] && warn "Only $(mem_avail_mb) MB RAM available now: close apps before starting."
info "Android may kill Termux in background: disable battery optimization; use 'termux-wake-lock' (start.sh does)."
[ "$bad" -eq 0 ] && ok "All checks passed." || err "$bad check(s) failed."
exit "$bad"
