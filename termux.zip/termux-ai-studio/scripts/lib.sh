#!/usr/bin/env bash
# Shared helpers for Termux AI Studio. Source this file; do not execute it.
TAS_VERSION="0.1.0"
_src="$(readlink -f "${BASH_SOURCE[0]}")"
TAS_ROOT="$(cd "$(dirname "$_src")/.." && pwd)"
AI_HOME="${AI_HOME:-$HOME/.termux-ai-studio}"
MODELS_DIR="$AI_HOME/models"
LOG_DIR="$AI_HOME/logs"
RUN_DIR="$AI_HOME/run"
PID_FILE="$RUN_DIR/llama-server.pid"
LOG_FILE="$LOG_DIR/llama-server.log"
USER_CONF="$AI_HOME/model.conf"
OPENCODE_CONF="${OPENCODE_CONFIG_PATH:-$HOME/.config/opencode/opencode.json}"
PROVIDER_ID="termux-local"

if [ -t 1 ]; then R=$'\033[31m'; G=$'\033[32m'; Y=$'\033[33m'; B=$'\033[34m'; N=$'\033[0m'; else R=""; G=""; Y=""; B=""; N=""; fi
info() { printf '%s[i]%s %s\n' "$B" "$N" "$*"; }
ok()   { printf '%s[ok]%s %s\n' "$G" "$N" "$*"; }
warn() { printf '%s[!]%s %s\n' "$Y" "$N" "$*" >&2; }
err()  { printf '%s[x]%s %s\n' "$R" "$N" "$*" >&2; }
die()  { err "$*"; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

load_config() {
  local f="$TAS_ROOT/config/model.conf"
  [ -f "$USER_CONF" ] && f="$USER_CONF"
  [ -f "$f" ] || die "Config not found: $f"
  # shellcheck disable=SC1090
  . "$f"
  : "${MODEL_REPO:=}" "${MODEL_FILE:=}" "${MODEL_SHA256:=}"
  : "${SERVER_HOST:=127.0.0.1}" "${SERVER_PORT:=8081}" "${CTX:=2048}"
  : "${THREADS:=}" "${MODEL_ALIAS:=local-coder}" "${USE_JINJA:=1}" "${SERVER_EXTRA_ARGS:=}"
  if [ -z "$THREADS" ]; then
    THREADS="$(nproc 2>/dev/null || echo 4)"
    # leave headroom for Android: use at most 4 by default
    [ "$THREADS" -gt 4 ] && THREADS=4
  fi
  case "$SERVER_HOST" in
    127.0.0.1|localhost|::1) ;;
    *) [ "${ALLOW_NON_LOCAL:-0}" = "1" ] || die "SERVER_HOST=$SERVER_HOST is not localhost. Refusing (set ALLOW_NON_LOCAL=1 only if you understand the risk)." ;;
  esac
  [[ "$SERVER_PORT" =~ ^[0-9]+$ ]] || die "Invalid SERVER_PORT: $SERVER_PORT"
  [[ "$CTX" =~ ^[0-9]+$ ]] || die "Invalid CTX: $CTX"
}

model_path() { printf '%s/%s' "$MODELS_DIR" "$MODEL_FILE"; }
ensure_dirs() { mkdir -p "$MODELS_DIR" "$LOG_DIR" "$RUN_DIR"; }
port_open()   { (exec 3<>"/dev/tcp/$1/$2") 2>/dev/null; }
api_health()  { curl -fsS --max-time 3 "http://$SERVER_HOST:$SERVER_PORT/health" >/dev/null 2>&1; }
pid_alive()   { [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; }
mem_total_mb() { awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 0; }
mem_avail_mb() { awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 0; }
free_mb()      { df -Pk "${1:-$HOME}" 2>/dev/null | awk 'NR==2{print int($4/1024)}'; }

# set_conf KEY VALUE -> persists into user config (created from default if missing)
set_conf() {
  local k="$1" v="$2"
  [[ "$k" =~ ^[A-Z0-9_]+$ ]] || die "Bad key: $k"
  [[ "$v" =~ ^[A-Za-z0-9._/:@=-]*$ ]] || die "Value contains unsupported characters: $v"
  mkdir -p "$AI_HOME"
  [ -f "$USER_CONF" ] || cp "$TAS_ROOT/config/model.conf" "$USER_CONF"
  if grep -q "^$k=" "$USER_CONF"; then
    sed -i "s|^$k=.*|$k=\"$v\"|" "$USER_CONF"
  else
    printf '%s="%s"\n' "$k" "$v" >> "$USER_CONF"
  fi
}
