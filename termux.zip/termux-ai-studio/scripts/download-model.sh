#!/usr/bin/env bash
# Downloads the configured GGUF from Hugging Face after verifying it exists.
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/lib.sh"
load_config; ensure_dirs
for t in curl jq; do have "$t" || die "$t not installed (pkg install $t)."; done

if [ -z "$MODEL_REPO" ] || [ -z "$MODEL_FILE" ]; then
  [ -t 0 ] || die "No model configured. Run: ai model set OWNER/REPO FILE.gguf"
  echo "Enter the Hugging Face repo and GGUF filename of the model you want."
  echo "(Find them on the model page: 'Files and versions'. Q4_K_M recommended.)"
  read -r -p "Repo (owner/name): " r; read -r -p "File (*.gguf):   " f
  set_conf MODEL_REPO "$r"; set_conf MODEL_FILE "$f"; load_config
fi
[[ "$MODEL_REPO" =~ ^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$ ]] || die "Invalid repo: $MODEL_REPO"
[[ "$MODEL_FILE" =~ ^[A-Za-z0-9._-]+\.gguf$ ]] || die "Invalid filename: $MODEL_FILE"

dest="$(model_path)"
if [ -f "$dest" ] && bash "$TAS_ROOT/scripts/verify-model.sh" "$dest" >/dev/null 2>&1; then ok "Model already present and valid: $dest"; exit 0; fi

info "Checking $MODEL_REPO on Hugging Face ..."
api="$(curl -fsS --max-time 30 "https://huggingface.co/api/models/$MODEL_REPO?blobs=true")" \
  || die "Repo not reachable/not found: https://huggingface.co/$MODEL_REPO (check spelling and internet)."
echo "$api" | jq -e --arg f "$MODEL_FILE" '.siblings[]? | select(.rfilename==$f)' >/dev/null \
  || { err "File '$MODEL_FILE' does not exist in $MODEL_REPO. Available .gguf files:"; echo "$api" | jq -r '.siblings[]?.rfilename | select(endswith(".gguf"))' >&2; exit 1; }
lic="$(echo "$api" | jq -r '[.tags[]? | select(startswith("license"))] | join(", ")')"
info "License tags: ${lic:-none declared}. Read the model card before use/redistribution."
exp_size="$(echo "$api" | jq -r --arg f "$MODEL_FILE" '.siblings[]|select(.rfilename==$f)|.size // 0')"
if [ -z "$MODEL_SHA256" ]; then
  sha="$(echo "$api" | jq -r --arg f "$MODEL_FILE" '.siblings[]|select(.rfilename==$f)|.lfs.sha256 // empty')"
  [ -n "$sha" ] && { set_conf MODEL_SHA256 "$sha"; load_config; info "Expected SHA-256 from API: $sha"; }
fi
need=$(( (exp_size / 1024 / 1024) + 500 ))
[ "$(free_mb "$MODELS_DIR")" -ge "$need" ] || die "Not enough free storage: need ~${need} MB."

if [ "${AI_YES:-0}" != "1" ] && [ -t 0 ]; then
  read -r -p "Download $MODEL_FILE (~$((exp_size/1024/1024)) MB) from $MODEL_REPO? [y/N] " a
  [[ "$a" =~ ^[Yy]$ ]] || die "Cancelled."
fi
url="https://huggingface.co/$MODEL_REPO/resolve/main/$MODEL_FILE"
info "Downloading (resumable): $url"
curl --fail --location --retry 5 --retry-delay 3 --continue-at - --progress-bar -o "$dest.part" "$url" \
  || die "Download failed. Re-run the same command to resume."
bash "$TAS_ROOT/scripts/verify-model.sh" "$dest.part" || { err "Verification failed; keeping $dest.part for inspection."; exit 1; }
mv "$dest.part" "$dest"
ok "Model ready: $dest"
