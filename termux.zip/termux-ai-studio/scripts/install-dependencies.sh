#!/usr/bin/env bash
# Installs Termux packages (verified to exist first) and OpenCode (best effort).
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/lib.sh"
have pkg || die "'pkg' not found: this script must run in Termux."

PKGS=(git curl jq nodejs llama-cpp)
for p in "${PKGS[@]}"; do
  if pkg show "$p" >/dev/null 2>&1; then :; else die "Termux package '$p' not found in your mirror. Run 'pkg update' or 'termux-change-repo', then retry."; fi
done
info "Installing: ${PKGS[*]}"
pkg install -y "${PKGS[@]}"
have llama-server || die "llama-server not found after installing llama-cpp. See docs/TROUBLESHOOTING.md."
ok "llama-server: $(command -v llama-server)"

if have opencode; then ok "OpenCode already installed: $(opencode --version 2>/dev/null || echo '?')"; exit 0; fi
info "Installing OpenCode via npm (package: opencode-ai) ..."
if npm install -g opencode-ai && have opencode && opencode --version >/dev/null 2>&1; then
  ok "OpenCode installed: $(opencode --version)"
else
  warn "OpenCode could not be installed/run natively on Termux."
  warn "The local server still works. See docs/TROUBLESHOOTING.md -> 'npm installation failures' (proot-distro fallback)."
  exit 0
fi
