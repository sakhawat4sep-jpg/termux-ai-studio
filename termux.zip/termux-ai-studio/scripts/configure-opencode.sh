#!/usr/bin/env bash
# Writes/merges the local provider into OpenCode's config. Backs up any existing file.
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/lib.sh"
load_config
have jq || die "jq missing (pkg install jq)."
tpl="$TAS_ROOT/config/opencode.json"
jq empty "$tpl" || die "Template is invalid JSON: $tpl"

gen="$(jq --arg url "http://$SERVER_HOST:$SERVER_PORT/v1" --arg id "$MODEL_ALIAS" --argjson ctx "$CTX" --arg pid "$PROVIDER_ID" '
  .provider[$pid].options.baseURL = $url
  | .provider[$pid].models = { ($id): { name: "Local coder (llama.cpp)", limit: { context: $ctx, output: ([($ctx/2|floor),4096]|min) } } }
  | .model = ($pid + "/" + $id)' "$tpl")"

mkdir -p "$(dirname "$OPENCODE_CONF")"
if [ -f "$OPENCODE_CONF" ]; then
  jq empty "$OPENCODE_CONF" 2>/dev/null || die "Existing $OPENCODE_CONF is not strict JSON (comments?). Not touching it. Merge this manually:\n$gen"
  bak="$OPENCODE_CONF.bak.$(date +%Y%m%d%H%M%S)"; cp -p "$OPENCODE_CONF" "$bak"; info "Backup: $bak"
  merged="$(jq -s '.[0] * .[1]' "$OPENCODE_CONF" <(printf '%s' "$gen"))"
else merged="$gen"; fi
tmp="$(mktemp)"; printf '%s\n' "$merged" > "$tmp"; jq empty "$tmp" || die "Generated config invalid."
mv "$tmp" "$OPENCODE_CONF"
ok "OpenCode configured: $OPENCODE_CONF (provider '$PROVIDER_ID', model '$PROVIDER_ID/$MODEL_ALIAS', no API key needed)"
