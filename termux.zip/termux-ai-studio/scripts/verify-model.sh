#!/usr/bin/env bash
# Usage: verify-model.sh [path]   Checks existence, size, GGUF magic, optional SHA-256.
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/lib.sh"
load_config
f="${1:-$(model_path)}"
[ -f "$f" ] || die "Model file not found: $f"
size="$(wc -c < "$f")"
[ "$size" -ge 52428800 ] || die "File too small (${size} bytes): incomplete download? Delete it and re-download."
magic="$(head -c 4 "$f")"
[ "$magic" = "GGUF" ] || die "Not a GGUF file (bad magic). It may be an HTML error page or another format."
if [ -n "${MODEL_SHA256:-}" ]; then
  have sha256sum || die "sha256sum missing (pkg install coreutils)."
  got="$(sha256sum "$f" | awk '{print $1}')"
  [ "$got" = "$MODEL_SHA256" ] || die "SHA-256 mismatch. expected=$MODEL_SHA256 got=$got"
  ok "SHA-256 matches."
else warn "No SHA-256 available: verified size and GGUF header only."; fi
ok "Model OK: $f ($((size/1024/1024)) MB)"
