#!/usr/bin/env bash
# Tests the local OpenAI-compatible API. With --opencode also checks OpenCode hits the local server.
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/lib.sh"
load_config; have curl || die "curl missing"; have jq || die "jq missing"
base="http://$SERVER_HOST:$SERVER_PORT"
api_health || die "Server not ready at $base (try: ai start)."
ok "/health OK"
curl -fsS --max-time 10 "$base/v1/models" | jq -e '.data|length>0' >/dev/null && ok "/v1/models OK" || die "/v1/models failed"
resp="$(curl -fsS --max-time 300 "$base/v1/chat/completions" -H 'Content-Type: application/json' \
  -d "$(jq -n --arg m "$MODEL_ALIAS" '{model:$m,max_tokens:24,messages:[{role:"user",content:"Reply with the single word: pong"}]}')")" \
  || die "Chat completion failed. See: ai logs"
echo "$resp" | jq -e '.choices[0].message' >/dev/null || die "Unexpected response: $resp"
ok "Chat completion OK: $(echo "$resp" | jq -r '.choices[0].message.content' | head -c 80)"
if [ "${1:-}" = "--opencode" ]; then
  have opencode || die "opencode not installed."
  before="$(grep -c 'POST /v1/chat/completions' "$LOG_FILE" 2>/dev/null || true)"; before="${before:-0}"
  opencode run -m "$PROVIDER_ID/$MODEL_ALIAS" "Say hi in one word." >/dev/null 2>&1 || warn "opencode run returned non-zero"
  after="$(grep -c 'POST /v1/chat/completions' "$LOG_FILE" 2>/dev/null || true)"; after="${after:-0}"
  [ "$after" -gt "$before" ] && ok "OpenCode request reached the LOCAL server (log count $before -> $after)." \
    || warn "No new request seen in the local server log: OpenCode may not be using the local model."
fi
