#!/usr/bin/env bash
# Starts llama-server on localhost. Idempotent: never starts a duplicate.
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/lib.sh"
load_config; ensure_dirs
have llama-server || die "llama-server not found. Run: pkg install llama-cpp"
[ -n "$MODEL_FILE" ] || die "No model configured. Run: ai model set OWNER/REPO FILE.gguf && ai model download"
mp="$(model_path)"; [ -f "$mp" ] || die "Model file missing: $mp  (run: ai model download)"

if pid_alive && api_health; then ok "Server already running (PID $(cat "$PID_FILE")) on http://$SERVER_HOST:$SERVER_PORT"; exit 0; fi
pid_alive && { warn "Stale/unready process $(cat "$PID_FILE"); stopping it."; bash "$TAS_ROOT/stop.sh" >/dev/null || true; }
if port_open "$SERVER_HOST" "$SERVER_PORT"; then die "Port $SERVER_PORT already in use by another program. Change it: edit SERVER_PORT in $USER_CONF (diagnose: see docs/TROUBLESHOOTING.md)."; fi

[ -f "$LOG_FILE" ] && [ "$(wc -c < "$LOG_FILE")" -gt 5242880 ] && mv "$LOG_FILE" "$LOG_FILE.old"
args=(-m "$mp" --host "$SERVER_HOST" --port "$SERVER_PORT" -c "$CTX" -t "$THREADS" --alias "$MODEL_ALIAS" -np 1)
[ "$USE_JINJA" = "1" ] && args+=(--jinja)
# shellcheck disable=SC2206
[ -n "$SERVER_EXTRA_ARGS" ] && args+=($SERVER_EXTRA_ARGS)

have termux-wake-lock && termux-wake-lock || true
info "Starting llama-server (ctx=$CTX threads=$THREADS) ..."
{ echo "=== $(date -Is) start: llama-server ${args[*]}"; } >> "$LOG_FILE"
nohup llama-server "${args[@]}" >> "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

for i in $(seq 1 240); do
  if ! pid_alive; then
    err "llama-server exited during startup. Last log lines:"; tail -n 25 "$LOG_FILE" >&2
    err "Hints: out of memory -> lower CTX / smaller model; unknown argument -> set USE_JINJA=0; unsupported architecture -> update llama-cpp."
    rm -f "$PID_FILE"; exit 1
  fi
  if api_health; then ok "Server ready after ~${i}s: http://$SERVER_HOST:$SERVER_PORT/v1  (model alias: $MODEL_ALIAS)"; exit 0; fi
  sleep 1
done
err "Timed out waiting for the server (240s). See: ai logs"; exit 1
