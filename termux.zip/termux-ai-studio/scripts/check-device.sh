#!/usr/bin/env bash
# Checks Android/Termux, ARM64, storage and RAM. Exit 1 on hard failure.
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/lib.sh"
fail=0
if [ "${AI_SKIP_DEVICE_CHECK:-0}" = "1" ]; then warn "AI_SKIP_DEVICE_CHECK=1: skipping Android/Termux checks (testing mode)."; exit 0; fi

if [ -n "${TERMUX_VERSION:-}" ] || [ -d /data/data/com.termux ]; then ok "Termux detected ${TERMUX_VERSION:-}"
else err "Not running inside Termux. Install Termux (F-Droid or GitHub releases), not the outdated Play Store build."; fail=1; fi

arch="$(uname -m)"
case "$arch" in aarch64|arm64) ok "Architecture: $arch" ;;
  *) err "Unsupported architecture: $arch (ARM64 required)."; fail=1 ;; esac

if have getprop; then info "Android $(getprop ro.build.version.release 2>/dev/null || echo '?') (SDK $(getprop ro.build.version.sdk 2>/dev/null || echo '?'))"; fi

free="$(free_mb "$HOME")"; free="${free:-0}"
if [ "$free" -lt 4096 ]; then err "Free storage ${free} MB < 4096 MB required (model ~2 GB + packages)."; fail=1
else ok "Free storage: ${free} MB"; fi

ram="$(mem_total_mb)"
if [ "$ram" -eq 0 ]; then warn "Could not read RAM."
elif [ "$ram" -lt 3500 ]; then warn "RAM ${ram} MB: a 3B Q4 model will likely be killed. Use a smaller model."
elif [ "$ram" -lt 5500 ]; then warn "RAM ${ram} MB: keep CTX=2048 and close other apps."
else ok "RAM: ${ram} MB"; fi
[ "$fail" -eq 0 ] || exit 1
