#!/usr/bin/env bash
exec bash "$(dirname "$(readlink -f "$0")")/scripts/start-server.sh" "$@"
