# Model guide

**Target:** Qwen2.5-Coder-3B (abliterated), GGUF, Q4_K_M (~2 GB).

- Default (found on Hugging Face, re-checked by the installer): repo `bartowski/Qwen2.5-Coder-3B-Instruct-abliterated-GGUF`, file `Qwen2.5-Coder-3B-Instruct-abliterated-Q4_K_M.gguf` (~1.93 GB).
- To use another model: `ai model set OWNER/REPO FILE.gguf && ai model download`
- "Abliterated" means refusal behaviour was reduced by editing the weights. It does not guarantee unrestricted output, and quality can be slightly lower than the original.
- **License:** check the model card. As far as I recall, Qwen2.5-Coder-3B is under the Qwen Research License (non-commercial), unlike some other sizes; abliterated derivatives inherit the base terms. Confirm before any commercial use. Weights are never included in this repo.
- The installer never swaps models silently. Any GGUF supported by your llama.cpp build works.
- RAM guide: 3B Q4_K_M ≈ 2 GB weights + KV cache. On 6 GB devices keep CTX 2048-4096; try 8192 only with free RAM.
