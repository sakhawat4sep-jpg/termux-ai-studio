# Publish to GitHub

```
cd termux-ai-studio
git init -b main
git add .
git commit -m "Initial commit: Termux AI Studio 0.1.0"
# create an empty repo named termux-ai-studio on github.com first, then:
git remote add origin https://github.com/YOUR-USER/termux-ai-studio.git
git push -u origin main
```
Make sure scripts keep their executable bit: `git update-index --chmod=+x *.sh scripts/*.sh bin/ai`.
Replace `YOUR-USER` in README/docs with your GitHub username.
