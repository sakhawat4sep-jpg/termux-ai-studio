# Verification status (be honest about what was tested)

This repository was generated in a sandbox WITHOUT internet access and WITHOUT an Android device.

| Item | Status |
|---|---|
| Bash syntax (`bash -n`) of all scripts | Done |
| `config/opencode.json` valid JSON | Done (python json) |
| Config handling, `ai model set/show`, GGUF header/size check, localhost-only guard, stop/status logic | Exercised in a Linux sandbox |
| `configure-opencode.sh`, `uninstall.sh` jq logic | NOT run (jq unavailable in sandbox); filters reviewed by hand |
| Hugging Face model repo + exact GGUF filename | FOUND via web search (bartowski/Qwen2.5-Coder-3B-Instruct-abliterated-GGUF, file ...-abliterated-Q4_K_M.gguf, ~1.93 GB). Actual download NOT run; installer re-checks via HF API |
| Termux package names | `llama-cpp` seen in third-party install docs (not an official Termux page); `nodejs`, `jq`, `curl`, `git` NOT checked. Installer checks each with `pkg show` |
| llama-server flags (`--jinja`, `-np`, `--alias`) | NOT verified against the Termux build |
| OpenCode schema (`provider.<id>.npm = @ai-sdk/openai-compatible`, `options.baseURL`, `models.<id>.name`, `limit.context/output`, top-level `model`) | MATCHES the OpenCode V1 docs and a llama.cpp example found online. NOTE: OpenCode now has V2 docs (https://opencode.ai/docs/llms.txt) whose examples use a `providers` key; if your installed OpenCode is V2, re-check the schema |
| `npm install -g opencode-ai` on Termux | NOT verified; may fail (see TROUBLESHOOTING) |
| Real Android device run | NOT done |

Please check the OpenCode docs (https://opencode.ai/docs/providers/) and report the tested version here after your first run.
