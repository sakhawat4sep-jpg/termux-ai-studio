# Installation

1. Install Termux from F-Droid or the official GitHub releases (the Play Store build is outdated).
2. In Termux:
   ```
   pkg update && pkg upgrade -y
   pkg install -y git
   git clone https://github.com/YOUR-USER/termux-ai-studio.git
   cd termux-ai-studio
   bash install.sh
   ```
3. When asked, enter the Hugging Face repo and `.gguf` filename of your model (see MODEL-GUIDE.md). The installer verifies they exist before downloading.
4. Start coding: `ai opencode`

Requirements: Android 7+ (newer recommended), ARM64, 6 GB RAM recommended, 4+ GB free storage.
Non-interactive: `AI_YES=1 bash install.sh` after `ai model set OWNER/REPO FILE.gguf`.
Custom location: `AI_HOME=/path bash install.sh`.
