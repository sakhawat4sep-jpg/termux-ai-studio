# Troubleshooting

Run `ai doctor` first. Each entry: diagnose -> fix. Fixes marked (untested) were not run on a device.

**wget not installed** — `command -v wget` -> `pkg install wget`. (This project uses curl: `pkg install curl`.)

**Model download failure** — `curl -I https://huggingface.co` ; `ai model show`. Re-run `ai model download` (it resumes). Check repo/file spelling; the script lists available .gguf files if the name is wrong.

**Invalid or incomplete GGUF** — `bash scripts/verify-model.sh` ; `head -c 4 FILE` must print `GGUF`. Delete the file and re-download.

**Unsupported GGUF architecture** — `ai logs` shows `unknown model architecture`. Update: `pkg upgrade llama-cpp` (or `ai update`); otherwise pick another model.

**llama-server not found** — `command -v llama-server ; pkg show llama-cpp`. `pkg update && pkg install llama-cpp`. If the package is missing, `termux-change-repo`.

**Model loading failure** — `ai logs`. Common: wrong path (`ai model show`), corrupted file (verify), unknown argument (set `USE_JINJA="0"` in `~/.termux-ai-studio/model.conf`).

**Out-of-memory / process "Killed"** — `free -m ; ai logs`. Lower context (`ai model ctx 2048`), close apps, use a smaller quant/model, reduce threads.

**ECONNREFUSED** — `ai status ; curl http://127.0.0.1:8081/health`. Server not running or still loading: `ai start`. Model loading takes up to a few minutes.

**Port already in use** — `ss -ltnp | grep 8081` (or `curl 127.0.0.1:8081/health`). `ai stop`, or change `SERVER_PORT` in `~/.termux-ai-studio/model.conf` then `bash scripts/configure-opencode.sh`.

**OpenCode provider errors** — `jq . ~/.config/opencode/opencode.json` ; `ai test`. Re-run `bash scripts/configure-opencode.sh`. Compare with https://opencode.ai/docs/providers/ (schema may have changed). "Context exceeded": `ai model ctx 4096` and restart.

**npm installation failures** — `node -v ; npm -v ; npm install -g opencode-ai`. OpenCode ships native binaries that may not run on Termux's Android libc (untested). Fallbacks: (a) `pkg install proot-distro && proot-distro install ubuntu`, install OpenCode inside, and point it at `http://127.0.0.1:8081/v1` (proot shares localhost); (b) use another OpenAI-compatible client; llama-server also has a built-in web UI at http://127.0.0.1:8081.

**Android background process termination** — Disable battery optimization for Termux, lock the app in recents, run `termux-wake-lock` (start.sh does), and on Android 12+ disable the "phantom process killer" via developer options / `adb shell` if available. Check `ai status` after returning to Termux.
