# Building Android apps with OpenCode (honest guide)

OpenCode + a 3B local model can draft Kotlin/Java, Jetpack Compose UI, XML layouts and Gradle snippets, and explain build errors. It will NOT reliably build complex apps by itself: expect small tasks, review every change, and iterate.

**Toolchain on Termux is the hard part.** The official Android SDK/Gradle/AAPT2 tools target desktop Linux/macOS/Windows; on Termux they are unofficial and often break (aapt2 binaries, glibc vs bionic). Options:
- Use community Termux builds of the SDK/Gradle (check current status before relying on them).
- Use a PC/CI for builds and the phone only for code generation (recommended for reliability).
- Use proot-distro Ubuntu (ARM64) for Gradle + JDK 17; the SDK's x86-only tools won't work, so verify `aapt2` first.

**Workflow:** create a project with Android Studio template (or Gradle init), commit to git, ask OpenCode for one change at a time ("add a Compose screen with a text field and button"), run `./gradlew assembleDebug`, paste the first error back, repeat. Debug with `adb logcat` (wireless debugging) or Android Studio on a PC. Keep prompts small to fit the context window.
