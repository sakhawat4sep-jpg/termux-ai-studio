# FAQ

**Is it free?** Local inference needs no API key or subscription.
**Is it private?** Inference stays on-device; the server listens on 127.0.0.1 only. Downloads/updates use the internet.
**How fast is it?** A few tokens per second on mid-range phones; expect waiting.
**Is a 3B model smart enough?** For small edits and explanations, often. Not for large autonomous builds.
**Can I use another model?** Yes: `ai model set OWNER/REPO FILE.gguf && ai model download`.
**Why is the model not preconfigured?** It could not be verified at generation time; see docs/VERIFICATION.md.
**Does it work on iOS/x86?** No.
