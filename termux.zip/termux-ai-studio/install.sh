#!/usr/bin/env bash
# Termux AI Studio installer.  Usage: bash install.sh
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
. "$ROOT/scripts/lib.sh"
trap 'err "Installer failed at line $LINENO. See docs/TROUBLESHOOTING.md or run: bash doctor.sh"' ERR

echo "== Termux AI Studio $TAS_VERSION installer =="
info "[1/7] Checking device";            bash "$ROOT/scripts/check-device.sh"
info "[2/7] Installing dependencies";    bash "$ROOT/scripts/install-dependencies.sh"
info "[3/7] Creating directories";       ensure_dirs; [ -f "$USER_CONF" ] || cp "$ROOT/config/model.conf" "$USER_CONF"; ok "$AI_HOME"
info "[4/7] Downloading + verifying model"; bash "$ROOT/scripts/download-model.sh"
info "[5/7] Configuring OpenCode";       bash "$ROOT/scripts/configure-opencode.sh"
info "[6/7] Installing 'ai' command"
if [ -n "${PREFIX:-}" ] && [ -d "$PREFIX/bin" ]; then
  ln -sf "$ROOT/bin/ai" "$PREFIX/bin/ai"; ok "ai -> $PREFIX/bin/ai"
else warn "\$PREFIX/bin not found; run commands as: bash $ROOT/bin/ai <cmd>"; fi
info "[7/7] Health check"
bash "$ROOT/start.sh" && bash "$ROOT/scripts/test-api.sh" || { err "Health check failed. Run: bash $ROOT/doctor.sh"; exit 1; }
echo
ok "Installation complete."
echo "Next:  ai opencode      (starts server if needed, then OpenCode)"
echo "Tip :  disable battery optimization for Termux; run 'ai stop' when done."
