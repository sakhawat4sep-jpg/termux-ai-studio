# Changelog

## 0.1.0 - initial release
- Installer, `ai` launcher, llama-server management, OpenCode provider config.
- Model repo/filename and OpenCode provider schema checked against online sources;
  OpenCode on Termux and llama-server flags are UNVERIFIED. Not tested on a physical Android device. See docs/VERIFICATION.md.
