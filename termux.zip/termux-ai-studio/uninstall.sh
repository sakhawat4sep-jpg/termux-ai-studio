#!/usr/bin/env bash
# Removes launcher, server state and our OpenCode provider entry (with backup). Asks before deleting models.
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/scripts/lib.sh"
ask() { [ "${AI_YES:-0}" = "1" ] && return 0; [ -t 0 ] || return 1; read -r -p "$1 [y/N] " a; [[ "$a" =~ ^[Yy]$ ]]; }
bash "$TAS_ROOT/stop.sh" || true
[ -n "${PREFIX:-}" ] && [ -L "$PREFIX/bin/ai" ] && rm -f "$PREFIX/bin/ai" && ok "Removed ai launcher"
if [ -f "$OPENCODE_CONF" ] && have jq && jq empty "$OPENCODE_CONF" 2>/dev/null; then
  cp -p "$OPENCODE_CONF" "$OPENCODE_CONF.bak.$(date +%Y%m%d%H%M%S)"
  tmp="$(mktemp)"
  jq --arg p "$PROVIDER_ID" 'del(.provider[$p]) | if (.model // "" | startswith($p + "/")) then del(.model) else . end | if (.provider == {}) then del(.provider) else . end' "$OPENCODE_CONF" > "$tmp" && mv "$tmp" "$OPENCODE_CONF"
  ok "Removed '$PROVIDER_ID' from OpenCode config (backup kept)"
fi
if [ -d "$MODELS_DIR" ] && ask "Delete downloaded models in $MODELS_DIR?"; then rm -rf "$MODELS_DIR"; ok "Models deleted"; fi
if ask "Delete logs/config in $AI_HOME (except models)?"; then rm -rf "$LOG_DIR" "$RUN_DIR" "$USER_CONF"; rmdir "$AI_HOME" 2>/dev/null || true; fi
info "The repo folder itself and Termux packages were not removed."
