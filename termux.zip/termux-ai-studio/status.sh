#!/usr/bin/env bash
set -euo pipefail
. "$(dirname "$(readlink -f "$0")")/scripts/lib.sh"
load_config
echo "Termux AI Studio $TAS_VERSION"
echo "Model:  ${MODEL_FILE:-<not set>}   ctx=$CTX threads=$THREADS"
echo "URL:    http://$SERVER_HOST:$SERVER_PORT/v1"
if pid_alive; then
  pid="$(cat "$PID_FILE")"
  rss="$(awk '/VmRSS/{print int($2/1024)}' "/proc/$pid/status" 2>/dev/null || echo '?')"
  if api_health; then ok "RUNNING and ready (PID $pid, ~${rss} MB RSS)"; else warn "Process alive (PID $pid) but not ready (still loading?)"; fi
else
  echo "STOPPED"; port_open "$SERVER_HOST" "$SERVER_PORT" && warn "Port $SERVER_PORT is in use by another program."
fi
exit 0
