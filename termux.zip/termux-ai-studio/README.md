# Termux AI Studio

Run a **free, local AI coding assistant on your Android phone**: Termux + llama.cpp (`llama-server`) + a GGUF model + [OpenCode](https://opencode.ai/docs/), connected through a localhost OpenAI-compatible API. No paid API key needed for local inference.

> **Status: v0.1.0, untested on a physical device.** Not run on a real device; OpenCode on Termux and the llama-server flags are unverified. Read [docs/VERIFICATION.md](docs/VERIFICATION.md) first.

## Features
- One command install: `bash install.sh`
- `ai start | stop | status | doctor | update | model | logs | test | opencode`
- Server bound to `127.0.0.1` only, no duplicate processes, logs in `~/.termux-ai-studio/logs`
- Model checked on Hugging Face before download; resumable download; GGUF/SHA-256 verification
- OpenCode config merged safely (timestamped backup, never overwritten blindly)

## Screenshots
_(placeholders)_ `docs/img/install.png`, `docs/img/opencode.png`

## Requirements
Android 7+ (10+ recommended), ARM64, **6 GB RAM** recommended, **4 GB+ free storage** (model ~2 GB). Termux from F-Droid or GitHub releases.

## Install (English)
```
pkg update && pkg upgrade -y
pkg install -y git
git clone https://github.com/YOUR-USER/termux-ai-studio.git
cd termux-ai-studio
bash install.sh
```
The installer downloads the default model (bartowski Qwen2.5-Coder-3B abliterated Q4_K_M, ~1.9 GB; see [MODEL-GUIDE](docs/MODEL-GUIDE.md)), verifies it, configures OpenCode and runs a health check.

## ইনস্টল (বাংলা)
1. F-Droid বা GitHub থেকে **Termux** ইনস্টল করুন (Play Store-এর ভার্সন পুরনো)।
2. Termux খুলে নিচের কমান্ডগুলো এক এক করে চালান:
```
pkg update && pkg upgrade -y
pkg install -y git
git clone https://github.com/YOUR-USER/termux-ai-studio.git
cd termux-ai-studio
bash install.sh
```
3. ইনস্টলার নিজে থেকেই মডেল (~১.৯ GB) ডাউনলোড করবে, তারপর টেস্ট করবে — [MODEL-GUIDE](docs/MODEL-GUIDE.md) দেখুন।
4. ব্যবহার শুরু: `ai opencode` । শেষ হলে `ai stop` ।
টিপ: Termux-এর জন্য ব্যাটারি অপটিমাইজেশন বন্ধ রাখুন, নইলে Android ব্যাকগ্রাউন্ডে প্রসেস বন্ধ করে দিতে পারে।

## Usage
```
ai start        # start server (waits until ready)
ai opencode     # start server if needed + open OpenCode
ai status       # running? ready? memory
ai logs -f      # follow server log
ai model ctx 4096   # bigger context (more RAM)
ai stop
ai update       # update repo/llama.cpp/OpenCode (model untouched)
ai doctor       # diagnostics
```
**Prompt examples:** "Explain this function and add error handling." / "এই কোডে একটি লগইন ফর্ম যোগ করো।" / "Write a Kotlin data class for a Todo item." / "এই Gradle এরর কেন হচ্ছে বুঝিয়ে বলো।"

## OpenCode integration
`scripts/configure-opencode.sh` writes provider `termux-local` (`@ai-sdk/openai-compatible`, baseURL `http://127.0.0.1:8081/v1`) to `~/.config/opencode/opencode.json` and sets it as default model. `ai test --opencode` checks that OpenCode's request actually shows up in the **local** server log. Schema must be checked against current docs: https://opencode.ai/docs/providers/. Tested OpenCode version: _none yet_.

## Building Android apps
See [docs/ANDROID-APP-DEVELOPMENT.md](docs/ANDROID-APP-DEVELOPMENT.md). Short version: good for small, supervised steps; Android SDK/Gradle on Termux is unreliable; a 3B model will not build complex apps alone.

## Limitations
- **Context:** default `CTX=2048` is small; OpenCode's prompt and tools are large, so you will probably need `ai model ctx 4096` or 8192.
- 3B models make mistakes; speed is a few tokens/second.
- OpenCode may not run natively on Termux (see TROUBLESHOOTING).
- Android may kill background processes.

## Troubleshooting / FAQ
[docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md), [docs/FAQ.md](docs/FAQ.md)

## License and attribution
Scripts: MIT ([LICENSE](LICENSE)). Model weights are **not** included and keep their own licenses; Qwen2.5-Coder is by the Qwen team (Alibaba Cloud), and "abliterated" variants are community derivatives. llama.cpp (MIT) by ggml-org. OpenCode by its authors. "Abliterated" = reduced refusals, not guaranteed unrestricted.
